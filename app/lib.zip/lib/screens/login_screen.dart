import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    const appTitle = 'Bem Vindo!';

    return Scaffold(
      appBar: AppBar(title: const Text(appTitle)),
      body: const MyCustomForm(),
    );
  }
}

class MyCustomForm extends StatefulWidget {
  const MyCustomForm({super.key});

  @override
  MyCustomFormState createState() {
    return MyCustomFormState();
  }
}

class MyCustomFormState extends State<MyCustomForm> {
  final _formKey = GlobalKey<FormState>();
  bool _isLoading = false;

  @override
  Widget build(BuildContext context) {
    // Build a Form widget using the _formKey created above.
    return Form(
      key: _formKey,
      child: Padding(
        padding: const EdgeInsets.all(16.0), // Adiciona padding em toda a forma
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextFormField(
              decoration: const InputDecoration(
                labelText: 'Email',
                border: OutlineInputBorder()
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Por favor insira um email';
                }
                if (!value.contains('@')) {
                  return 'Email inválido';
                }
                return null;
              },
            ),
            const SizedBox(height: 16.0), // Espaço entre os campos
            TextFormField(
              obscureText: true, // Oculta a senha
              decoration: const InputDecoration(
                labelText: 'Senha',
                border: OutlineInputBorder()
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Por favor insira uma senha';
                }
                if (value.length <= 6) {
                  return 'A senha deve ter mais de 6 caracteres';
                }
                return null;
              },
            ),
            Padding(
              padding: const EdgeInsets.only(top: 24.0), // Espaço maior antes do botão
              child: SizedBox(
                width: double.infinity, // Botão ocupa toda a largura
                child: ElevatedButton(
                  onPressed: _isLoading ? null : () async {
                    // Validate returns true if the form is valid, or false otherwise.
                    if (_formKey.currentState!.validate()) {
                      setState(() {
                        _isLoading = true;
                      });
                      
                      // Simula um processo de login
                      await Future.delayed(const Duration(seconds: 2));
                      
                      if (mounted) {
                        setState(() {
                          _isLoading = false;
                        });
                        // Navega para a tela principal usando GoRouter
                        context.go('/home');
                      }
                    }
                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 12.0),
                    child: _isLoading 
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : const Text('Login'),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}